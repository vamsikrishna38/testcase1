import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

//const template = React.createElement('p', {}, 'Hello from react');
import Index from './components/Index';

ReactDOM.render(<Index />, document.getElementById('root'));