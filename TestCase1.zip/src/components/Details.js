import React from 'react'
import {Link} from 'react-router-dom';

export default function Details() {
    return (
        <div className="container pt-5">
            <div className="row">
                
            <div className="float-right" >
  <Link className="btn btn-primary" to="#" role="button" style={{margin:10}}>Add New</Link>
  <a className="btn btn-primary" href="#" role="button" style={{margin:10}} >Export Xml</a>
  <a className="btn btn-primary" href="#" role="button" style={{margin:10}} >Export Json</a>
</div>


            <table className="table">
  <thead className="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">First Name</th>
      <th scope="col">Email</th>
      <th scope="col">Street</th>
      <th scope="col">Zip</th>
      <th scope="col">City</th>
      <th scope="col">Edit</th>
    </tr>
  </thead>
  <tbody>
  <tr key="1">
  <td>1</td>
  <td>Vamsi</td>
  <td>Krishna</td>
  <td>test@gmail.com</td>
  <td>2nd Phase</td>
  <td>Hyd</td>
  <td>500081</td>
  <td><button className="btn btn-primary btn-xs" ><span className="fa fa-pencil"></span></button></td>
  </tr>
  <tr key="2">
  <td>2</td>
  <td>Demo</td>
  <td>Test</td>
  <td>demo@gmail.com</td>
  <td>2nd Phase</td>
  <td>Demo</td>
  <td>500081</td>
  <td><button className="btn btn-primary btn-xs" ><span className="fa fa-pencil"></span></button></td>
  </tr>
  </tbody>

  
  </table>
                </div>
                </div>
    )
}
